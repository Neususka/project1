# Java
Java is a class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.
